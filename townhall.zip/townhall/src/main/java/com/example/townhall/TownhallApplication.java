package com.example.townhall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TownhallApplication {

	public static void main(String[] args) {
		SpringApplication.run(TownhallApplication.class, args);
	}

}
