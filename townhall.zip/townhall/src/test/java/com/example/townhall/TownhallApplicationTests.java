package com.example.townhall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TownhallApplicationTests {

	@Test
	void contextLoads() {
	}

}
